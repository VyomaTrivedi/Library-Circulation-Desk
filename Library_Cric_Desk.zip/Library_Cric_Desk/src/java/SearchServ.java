/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Model.book;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author VYOMA
 */
public class SearchServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            Class.forName("com.mysql.jdbc.Driver");
            Connection con;
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management?" + "user=root&password=");
            String key=request.getParameter("Search_Key");
            PreparedStatement ps=con.prepareStatement("select book.isbn,book.title,authors.name,book.availability from book,authors,book_authors where book.isbn=book_authors.isbn and book_authors.author_id=authors.author_id and (book.title like '%"+key+"%' or authors.name like '%"+key+"%' or book.isbn like '%"+key+"%') order by book.isbn");
            
            
            ResultSet rs = null;
            ArrayList<book> list=new ArrayList<book>();
            rs= ps.executeQuery();
           
            while(rs.next())
            {
           
                book b=new book();
                b.setISBN(rs.getString(1));
                b.setTitle(rs.getString(2));
                b.setAuthor(rs.getString(3));
                b.setAvailability(rs.getInt(4));
                
                 // out.println(rs.getString(2));
                while(rs.next())
                {
                    if(b.getISBN().equals(rs.getString(1)))
                    {
                        b.setAuthor(b.getAuthor()+","+rs.getString(3));
                        //b.setAuthor(rs.getString(3));
                    }
                    else
                {
                    rs.previous();
                    break;
                }
                }
                
                list.add(b);
            }
             request.setAttribute("book",list);
            RequestDispatcher rd=request.getRequestDispatcher("Search.jsp");
            rd.forward(request, response);
        }
        catch(Exception e)
        {
            out.println(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
