/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Model.fine;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author VYOMA
 */
public class FineServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            Class.forName("com.mysql.jdbc.Driver");
            Connection con;
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management?" + "user=root&password=");
            String cid=request.getParameter("Borr_Key");
            String rvalue=request.getParameter("r1");
//            out.println(cid);
//            out.println(rvalue);
            
            if(rvalue.equals("UnPaid Fines"))
            {
                java.sql.PreparedStatement ps=con.prepareStatement("select fines.loan_id,fines.fine_amt,book_loans.card_id,book_loans.isbn,book.title,fines.paid from fines,book_loans,book where fines.loan_id=book_loans.loan_id and book.isbn=book_loans.isbn and fines.paid=0 and book_loans.card_id="+cid+";");
                ResultSet rs=null;
                rs=ps.executeQuery();
                ArrayList<fine> f=new ArrayList<fine>();
                while(rs.next())
                {
//                        out.println(rs.getInt(1));
//                        out.println(rs.getFloat(2));
//                        out.println(rs.getString(3));
//                        out.println(rs.getString(4));
                          fine f1=new fine();
                          f1.setLoan_id(rs.getInt(1));
                        f1.setFine_amt(rs.getFloat(2));
                          f1.setCard_id(rs.getInt(3));
                        f1.setIsbn(rs.getString(4));
                        f1.setTitle(rs.getString(5));
                        f1.setPaid(rs.getInt(6));
                        f.add(f1);
                          
                }
                request.setAttribute("flist", f);
            RequestDispatcher rd=request.getRequestDispatcher("fine.jsp");
            rd.forward(request, response);
            }
            if(rvalue.equals("Paid Fines"))
            {
                java.sql.PreparedStatement ps=con.prepareStatement("select fines.loan_id,fines.fine_amt,book_loans.card_id,book_loans.isbn,book.title,fines.paid from fines,book_loans,book where fines.loan_id=book_loans.loan_id and book.isbn=book_loans.isbn and fines.paid=1 and book_loans.card_id="+cid+";");
                ResultSet rs=null;
                rs=ps.executeQuery();
                ArrayList<fine> f=new ArrayList<fine>();
                while(rs.next())
                {
//                        out.println(rs.getInt(1));
//                        out.println(rs.getFloat(2));
//                        out.println(rs.getString(3));
//                        out.println(rs.getString(4));
                        fine f1=new fine();
                          f1.setLoan_id(rs.getInt(1));
                        f1.setFine_amt(rs.getFloat(2));
                          f1.setCard_id(rs.getInt(3));
                        f1.setIsbn(rs.getString(4));
                        f1.setTitle(rs.getString(5));
                        f1.setPaid(rs.getInt(6));
                        f.add(f1);
                }
                request.setAttribute("flist", f);
            RequestDispatcher rd=request.getRequestDispatcher("fine.jsp");
            rd.forward(request, response);
            }
            if(rvalue.equals("Both"))
            {
                java.sql.PreparedStatement ps=con.prepareStatement("select fines.loan_id,fines.fine_amt,book_loans.card_id,book_loans.isbn,book.title,fines.paid from fines,book_loans,book where fines.loan_id=book_loans.loan_id and book.isbn=book_loans.isbn and book_loans.card_id="+cid+";");
                ResultSet rs=null;
                rs=ps.executeQuery();
                ArrayList<fine> f=new ArrayList<fine>();
                while(rs.next())
                {
//                        out.println(rs.getInt(1));
//                        out.println(rs.getFloat(2));
//                        out.println(rs.getString(3));
//                        out.println(rs.getString(4));
                    fine f1=new fine();
                          f1.setLoan_id(rs.getInt(1));
                        f1.setFine_amt(rs.getFloat(2));
                          f1.setCard_id(rs.getInt(3));
                        f1.setIsbn(rs.getString(4));
                        f1.setTitle(rs.getString(5));
                        f1.setPaid(rs.getInt(6));
                        f.add(f1);

                }
                request.setAttribute("flist", f);
            RequestDispatcher rd=request.getRequestDispatcher("fine.jsp");
            rd.forward(request, response);

            }
            if(rvalue.equals("OverDue"))
            {
                java.sql.PreparedStatement ps=con.prepareStatement("select book_loans.due_date,book_loans.loan_id,book_loans.card_id,book.isbn,book.title from book,book_loans where book.isbn=book_loans.isbn and book_loans.date_in is null and book_loans.card_id="+cid+";");
                ResultSet rs=null;
                rs=ps.executeQuery();
                ArrayList<fine> list=new ArrayList<fine>();
                while(rs.next())
                {
                    String due_date=rs.getString(1);
                    Date d=new Date();
                    Date d2=null;
                    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
                    d2=sdf.parse(due_date);
                    int diff=(int)((d2.getTime()-d.getTime()))/(1000*60*60*24);
                    if(diff<0)
                    {
                        fine f=new fine();
                        f.setLoan_id(rs.getInt(2));
                        f.setCard_id(rs.getInt(3));
                        f.setIsbn(rs.getString(4));
                        f.setTitle(rs.getString(5));
                        list.add(f);
                        
                    }
                }
                request.setAttribute("flist", list);
            RequestDispatcher rd=request.getRequestDispatcher("OverDue.jsp");
            rd.forward(request, response);  
            }
            
            if(rvalue.equals("Settle Fines"))
            {
              java.sql.PreparedStatement ps=con.prepareStatement("select fines.loan_id,fines.fine_amt,book_loans.card_id,book_loans.isbn,book.title,fines.paid from fines,book_loans,book where fines.loan_id=book_loans.loan_id and book.isbn=book_loans.isbn and fines.paid=0 and book_loans.card_id="+cid+";");
                ResultSet rs=null;
                rs=ps.executeQuery();
                ArrayList<fine> f=new ArrayList<fine>();
                while(rs.next())
                {
//                        out.println(rs.getInt(1));
//                        out.println(rs.getFloat(2));
//                        out.println(rs.getString(3));
//                        out.println(rs.getString(4));
                          fine f1=new fine();
                          f1.setLoan_id(rs.getInt(1));
                        f1.setFine_amt(rs.getFloat(2));
                          f1.setCard_id(rs.getInt(3));
                        f1.setIsbn(rs.getString(4));
                        f1.setTitle(rs.getString(5));
                        f1.setPaid(rs.getInt(6));
                        f.add(f1);
                          
                }
                request.setAttribute("flist", f);
            RequestDispatcher rd=request.getRequestDispatcher("Settle.jsp");
            rd.forward(request, response);  
            }
//        if(rvalue.equals("Settle Fines"))
//            {
//                int lid=0;
//                java.sql.PreparedStatement ps=con.prepareStatement("select loan_id from book_loans where card_id="+cid+";");
//                //java.sql.PreparedStatement ps=con.prepareStatement("update fines set fines.paid=1 where fines.loan_id=book_loans.loan_id and book_loans.card_id="+cid+";");
//                ResultSet rs=null;
//                rs=ps.executeQuery();
//                while(rs.next())
//                {
//                        lid=rs.getInt(1);
//                        java.sql.PreparedStatement ps1=con.prepareStatement("update fines set paid=1 where loan_id="+lid+";");
//                        int b=0;
//                        b=ps1.executeUpdate();
//                }
//            }            
            
        }
        
        catch(Exception e)
        {
            out.print(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
