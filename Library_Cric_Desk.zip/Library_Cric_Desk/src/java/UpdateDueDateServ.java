/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author VYOMA
 */
public class UpdateDueDateServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String id=request.getParameter("CheckIn");
            //out.print(id);
            String cid=null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con;
            
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management?" + "user=root&password=");
            Date date = new Date();
            String dt= new SimpleDateFormat("yyyy-MM-dd").format(date);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String isbn=null;
            String ddt=null;
            java.sql.PreparedStatement ps=con.prepareStatement("update book_loans set date_in='"+dt+"' where loan_id="+id+";");
            int b=0;
            
            b=ps.executeUpdate();
            if(b>0)
            {
                RequestDispatcher rd=request.getRequestDispatcher("index_2.html");
            rd.forward(request, response); 
            }
            else
            {
                out.println("Check in failed");
            }
            java.sql.PreparedStatement ps1=con.prepareStatement("select isbn from book_loans where loan_id="+id+";");
            ResultSet rs=null;
            rs=ps1.executeQuery();
            if(rs.next())
            {
            isbn=rs.getString(1);
            }
            java.sql.PreparedStatement ps2=con.prepareStatement("update book set availability=1 where isbn="+isbn+";");
            int b1=0;
            b1=ps2.executeUpdate();
            java.sql.PreparedStatement ps3=con.prepareStatement("select card_id from book_loans where loan_id="+id+";");
            ResultSet rs1=null;
            rs1=ps3.executeQuery();
            if(rs1.next())
            {
                cid=rs1.getString(1);
            }
            out.println(cid);
            java.sql.PreparedStatement ps4=con.prepareStatement("update borrower set num_b=num_b-1 where card_id='"+cid+"';");
            int b2=0;
            b2=ps2.executeUpdate();
            java.sql.PreparedStatement ps5=con.prepareStatement("select due_date from book_loans where loan_id="+id+";");
            ResultSet rs2=null;
            rs2=ps5.executeQuery();
            if(rs2.next())
            {
                ddt=rs2.getString(1);
            }
            Date d1=null;
            Date d2=null;
            d1=sdf.parse(dt);
            d2=sdf.parse(ddt);
            int diff=(int)((d2.getTime()-d1.getTime())/(1000*60*60*24));
            double fine=0;
            int b3=0;
            if(diff<0)
            {
                fine=(-1)*diff*0.25;
                java.sql.PreparedStatement ps6=con.prepareStatement("insert into fines(loan_id,fine_amt) values ("+id+","+fine+");");
                b3=ps6.executeUpdate();
                if(b3>0)
                {
                    RequestDispatcher rd=request.getRequestDispatcher("index_2.html");
                rd.forward(request, response);
                }
            }
            
        }
        catch(Exception e)
        {
            out.print(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
