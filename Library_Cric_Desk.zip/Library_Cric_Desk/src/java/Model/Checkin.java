package Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author VYOMA
 */
public class Checkin {
    int Loan_id,Card_id;
    String isbn,Date_out,Due_date,Date_in;

    public int getLoan_id() {
        return Loan_id;
    }

    public void setLoan_id(int Loan_id) {
        this.Loan_id = Loan_id;
    }

    public int getCard_id() {
        return Card_id;
    }

    public void setCard_id(int Card_id) {
        this.Card_id = Card_id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getDate_out() {
        return Date_out;
    }

    public void setDate_out(String Date_out) {
        this.Date_out = Date_out;
    }

    public String getDue_date() {
        return Due_date;
    }

    public void setDue_date(String Due_date) {
        this.Due_date = Due_date;
    }

    public String getDate_in() {
        return Date_in;
    }

    public void setDate_in(String Date_in) {
        this.Date_in = Date_in;
    }
}
