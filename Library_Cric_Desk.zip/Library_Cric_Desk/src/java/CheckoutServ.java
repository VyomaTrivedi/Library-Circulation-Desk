/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.eclipse.persistence.expressions.ExpressionOperator;

/**
 *
 * @author VYOMA
 */
public class CheckoutServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            Class.forName("com.mysql.jdbc.Driver");
            Connection con;
            
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management?" + "user=root&password=");
            String n =  request.getParameter("isbn");
                                String n1 =  request.getParameter("cardid");
                                int avail = 0,cout = 0, count = 0, b=0,b1=0,b2=0;
            Statement st1 = con.createStatement();
                                ResultSet rs = st1.executeQuery("Select book.availability from book where book.isbn = '"+n+"';");
                                if(rs.next()){
                                avail = rs.getInt(1);}
                                ResultSet rs1 = st1.executeQuery("Select borrower.num_b from borrower where borrower.card_id = '"+n1+"';");
                                if(rs1.next()){
                                cout = rs1.getInt(1);}
                                ResultSet rs2 = st1.executeQuery("Select count(*) from book_loans;");
                                if(rs2.next()){
                                count = rs2.getInt(1);}
                                //out.println(avail+" "+cout+" "+count);
                                Date date = new Date();
                                String dt= new SimpleDateFormat("yyyy-MM-dd").format(date);

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                                Calendar c = Calendar.getInstance();
                                try {
                                c.setTime(sdf.parse(dt));
                                } catch (Exception e) {
                                e.printStackTrace();
                                }
                                c.add(Calendar.DATE, 14);  // number of days to add
                                String dt1 = sdf.format(c.getTime());
                                String query=("Select due_date from book_loans where date_in is null and card_id= '"+n1+"'");
                              int flag=0;
                                ResultSet rs7= st1.executeQuery(query);

                                while(rs7.next()){


                                Date due= (Date) sdf.parse(rs7.getString(1));

                                if(date.after(due)){

                                flag=1;
                                

}
                                }

                                
                                if ((avail == 1)&&(cout<3)&&(flag==0)){
                                String query0 = "insert into book_loans(loan_id,isbn,card_id,date_out,due_date) values('"+(count+1)+"','"+n+"','"+n1+"','"+dt+"','"+dt1+"');";
                                b=st1.executeUpdate(query0);
                                String query1 = "update borrower SET num_b=num_b+1 where borrower.card_id = '"+n1+"';";
                                b1=st1.executeUpdate(query1);
                                String query2 = "update book SET availability = 0 where isbn = '"+n+"';";
                                b2=st1.executeUpdate(query2);
                                if(b2>0)
                                {
                                RequestDispatcher rd=request.getRequestDispatcher("index_2.html");
                rd.forward(request, response);
                                }
                                else
                                {
                                    out.println("Book not available");
                                }
                                }
                           
//            String card=request.getParameter("cardid");
//            
//            int card_num=Integer.parseInt(card);
//            out.println(card_num);
//            PreparedStatement ps1=con.prepareStatement("select count(*),card_id from book_loans group by card_id having card_id ="+card_num+";");
//            ResultSet rs=ps1.executeQuery();
//            if(rs.next()){
//            count = rs.getInt(1);
//            out.print(count);
//            }
//            
//            int cnt=0;
//            PreparedStatement ps5=con.prepareStatement("select count(*) from book_loans");
//            ResultSet rs5=ps5.executeQuery();
//            if(rs5.next()){
//            cnt = rs5.getInt(1);
//            //out.print(cnt);
//            }
//            
//            Date date=new Date();
//            String dt=new SimpleDateFormat("yyyy-MM-dd").format(date);
//            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
//            Calendar c=Calendar.getInstance();
//            try {
//                c.setTime(sdf.parse(dt));
//            } catch (Exception e) {
//                out.println(e.getMessage());
//            }
//            c.add(Calendar.DATE, 14);
//            String dt1=sdf.format(c.getTime());
//            
//            
//           
//            PreparedStatement ps8=con.prepareStatement("select paid from book_loans,fines where book_loans.loan_id=fines.loan_id and card_id=1");
//            ResultSet rs4=ps8.executeQuery();
//            String status=rs4.getString(1);
//            out.print(status);
//            
//            PreparedStatement ps=con.prepareStatement("insert into book_loans(loan_id,isbn,card_id,date_out,due_date) values('"+(cnt+1)+"',?,?,'"+dt+"','"+dt1+"')");
//            ps.setString(1, request.getParameter("isbn"));
//            ps.setString(2, request.getParameter("cardid"));
//            int b=0;
//            
//            
//            if(count<3)
//            {
//                b=ps.executeUpdate();
//            }
        }
        catch(Exception e)
        {
            out.println(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
